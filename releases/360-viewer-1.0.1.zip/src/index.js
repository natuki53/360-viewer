/**
 * 360° Viewer Block
 * メインエントリーポイント
 */

// 各ブロックのインポート
import './blocks/360viewer/index.js';

// 将来的に他のブロックがある場合は、こちらにインポートを追加
// import './blocks/other-block/index.js'; 